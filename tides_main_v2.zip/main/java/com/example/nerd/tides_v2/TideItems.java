package com.example.nerd.tides_v2;

import java.util.ArrayList;

/**
 * Created by nerd on 7/15/2017.
 */


public class TideItems extends ArrayList<TideItem> {
    //Extending ArrayList for extensibility
    private String zip = null;
    private static final long serialVersionUID = 1L;

    public void setZip(String zipIn){
        zip = zipIn;
    }

    public String getZip(){
        return zip;
    }
    //Default Serial ID
}
