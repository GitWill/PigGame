package com.example.nerd.tides_v2;

import android.database.Cursor;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SimpleCursorAdapter;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import android.widget.Toast;

/**
 * Created by nerd on 7/15/2017.
 */

public class SecondActivity extends AppCompatActivity{

    Cursor cursor = null;
    SimpleCursorAdapter adapter = null;
    Dal dal = new Dal(this);
    String zip = null;
    String date = null;


    //depoe bay zip97341, coos bay97420, florence97439
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        zip = getIntent().getStringExtra("zip");
        date = getIntent().getStringExtra("date");

        cursor = dal.getForcastByLocation(zip, date);

        adapter = new SimpleCursorAdapter(
                this,
                R.layout.list_view_items,
                cursor,                             //this cursor is coming from getforcastbyloc
                new String[]{
                        TideSQLiteHelper.DATE,
                        TideSQLiteHelper.DAY,
                        TideSQLiteHelper.TIME,
                        TideSQLiteHelper.HEIGHT,
                        TideSQLiteHelper.HILO,

                },
                new int []{
                        R.id.dateTextView,
                        R.id.dayTextView,
                        R.id.timeTextView,
                        R.id.heightTextView,
                        R.id.hiLoTextView
                },
                0 );
        ListView itemsListView = (ListView)findViewById(R.id.tidesListView);
        itemsListView.setAdapter(adapter);
    }
}
