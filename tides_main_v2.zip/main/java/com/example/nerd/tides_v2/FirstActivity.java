package com.example.nerd.tides_v2;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.support.v4.widget.SimpleCursorAdapter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class FirstActivity extends AppCompatActivity
        implements AdapterView.OnItemClickListener, AdapterView.OnItemSelectedListener,View.OnClickListener{
    //get references to widgets
    Spinner locationSpinner;
    Spinner dateSpinner;
    Button myButton;
    Intent intent;
    String zip;
    String date;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);                        //set the first activity's layout
        myButton = (Button) findViewById(R.id.showTidesButton);         //get reference to local vars
        locationSpinner=(Spinner) findViewById(R.id.locationSpinner);
        dateSpinner=(Spinner) findViewById(R.id.dateSpinner);
        locationSpinner.setOnItemSelectedListener(this);                //set the listeners to the button and spinners
        dateSpinner.setOnItemSelectedListener(this);
        myButton.setOnClickListener(this);

    }

    @Override
    public void onClick(View v){
        if (v.getId() == R.id.showTidesButton){                         //if they clicked the show tides button
            zip = locationSpinner.getSelectedItem().toString();        //save the spinner selections
            if(zip.equals("Coos")){
                zip = "97420";
            }else if(zip.equals("Depoe")){
                zip = "97341";
            }else if(zip.equals("Florence")){
                zip = "97439";
            }
            //depoe bay zip97341, coos bay97420, florence97439

            date = dateSpinner.getSelectedItem().toString();            //in an intent
            intent = new Intent(this, SecondActivity.class);            //for the second activity
            intent.putExtra("zip",zip);
            intent.putExtra("date",date);
            startActivity(intent);
        }
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position,//USE THIS FOR SPINNER????
                               long id) {
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        // TODO Auto-generated method stub
    }
}
