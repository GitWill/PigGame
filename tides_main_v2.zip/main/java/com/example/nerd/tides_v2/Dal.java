package com.example.nerd.tides_v2;

/**
 * Created by nerd on 7/15/2017.
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import java.io.InputStream;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

public class Dal {
    Context context = null;

    public Dal(Context context)
    {
        this.context = context;
    }

    public void loadData(String zip)//this will load data into the DB
    {
        TideSQLiteHelper helper = new TideSQLiteHelper(context);

        SQLiteDatabase db = helper.getWritableDatabase();

        if (db.rawQuery("SELECT * FROM Tides WHERE " + TideSQLiteHelper.ZIP     //load thd DB if it's not already
                + "='" + zip +"'", null).getCount() == 0)
        {
            loadDbFromXML("97420");  //coos bay
            loadDbFromXML("97341");  //depoe bay
            loadDbFromXML("97439");  //florence
        }
        db.close();
    }


    // Parse the XML files and put the data in the db
    public void loadDbFromXML(String zip) {
        String fileName = zip +".xml";             //get reference to the xml file
        TideItems items = parseXmlFile(fileName);   //get reference to the items list
        items.setZip(zip);	// This field isn't in the xml file, so we add it here

        // Initialize database
        TideSQLiteHelper helper = new TideSQLiteHelper(context);
        SQLiteDatabase db = helper.getWritableDatabase();
        Log.d("willscomments", "single city database");
        // Put tide forecast in the database
        ContentValues cv = new ContentValues();

        for(TideItem item : items)
        {
            Log.d("willscomment", "adding to db");
            cv.put(TideSQLiteHelper.ZIP, items.getZip());				// These are creating cols
            cv.put(TideSQLiteHelper.DATE, item.getDate());
            cv.put(TideSQLiteHelper.DAY, item.getDay());
            cv.put(TideSQLiteHelper.TIME, item.getTime());
            cv.put(TideSQLiteHelper.HILO, item.getHilo());
            cv.put(TideSQLiteHelper.HEIGHT, item.getHeight());
            db.insert(TideSQLiteHelper.TIDES, null, cv);
        }
        db.close();
    }

    public Cursor getForcastByLocation(String zipIn,String dateIn)//gets string of cities and gives back a curser
    {
        loadData(zipIn);

        TideSQLiteHelper helper = new TideSQLiteHelper(context);        //initialize db
        SQLiteDatabase db = helper.getReadableDatabase();

        //get info for one of the zip codes
        String query = "SELECT * FROM Tides WHERE Zip = ? AND Date = ? ORDER BY Date ASC";
        String[] variables = new String[]{zipIn, dateIn};    // values to query by radix style??
        return db.rawQuery(query, variables);            // returns the query results
    }

    public TideItems parseXmlFile(String fileName) {
        try {
            // get the XML reader
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser parser = factory.newSAXParser();
            XMLReader xmlreader = parser.getXMLReader();

            // set content handler
            ParseHandler handler = new ParseHandler();
            xmlreader.setContentHandler(handler);

            // read the file from internal storage
            InputStream in = context.getAssets().open(fileName);

            // parse the data
            InputSource is = new InputSource(in);
            xmlreader.parse(is);

            // set the feed in the activity
            TideItems items = handler.getItems();
            return items;
        }
        catch (Exception e) {
            Log.e("News reader", e.toString());
            return null;
        }
    }
}
