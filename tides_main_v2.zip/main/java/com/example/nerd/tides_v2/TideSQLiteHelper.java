package com.example.nerd.tides_v2;

/**
 * Created by nerd on 7/15/2017.
 */

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class TideSQLiteHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "tides.sqlite";
    private static final int DATABASE_VERSION = 1;
    public static final String ZIP = "zip";
    public static final String TIDES = "Tides";
    public static final String DATE = "date";
    public static final String DAY = "day";
    public static final String TIME = "time";
    public static final String HEIGHT = "height";
    public static final String HILO = "hilo";


    Context context = null;

    public TideSQLiteHelper(Context c) {
        super(c, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = c;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(                                         //this only happens if the table is not empty
                "CREATE TABLE " + TIDES                     //create a table for the data
                + "( _id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + DATE + " TEXT,"
                + ZIP + " LONG,"
                + DAY + " TEXT,"
                + TIME + " TEXT,"
                + HEIGHT + " TEXT,"
                + HILO + " TEXT)"
        );

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub

    }

}