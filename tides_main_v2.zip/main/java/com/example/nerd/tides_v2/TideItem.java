package com.example.nerd.tides_v2;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.ParseException;

/**
 * Created by nerd on 7/13/2017.
 */

public class TideItem {
    private String date = null;         //TideItem instance vars
    private String day = null;          //used to store information about a single item
    private String time = null;
    private String hiLo = null;
    private String height = null;
    private String tideInfo = null;
    private String dateInfo = null;

    public String getTime(){
        return time;
    }

    public String getHeight(){
        return height;
    }

    public void setHeight(String heightIn){
        height = heightIn;
    }

    public String getTideInfo(){                    //format the tide info for the listview (bottom item)
        if(hiLo.equals("H"))
            tideInfo = "High:   " + time;
        else
            tideInfo = "Low: " + time;
        return tideInfo;
    }

    public String getDay(){
        return day;
    }

    public String getDate(){
        return date;
    }

    public String getHilo(){
        return hiLo;
    }

    public String getMetric(){                      //convert to metric, 1 foot = .3048
        double standard = Double.parseDouble(hiLo);
        double metric = (standard * 30.48);
        int metRounded = (int) metric;
        String met = Integer.toString(metRounded) + " cm.";
        return met;
    }


    //class mutators
    public void setDate(String dateIn){ date = dateIn; }

    public void setDay(String dayIn){ day = dayIn; }

    public void setTime(String timeIn){ time = timeIn; }

    public void setHiLo(String hiLoIn){hiLo = hiLoIn;}
}
