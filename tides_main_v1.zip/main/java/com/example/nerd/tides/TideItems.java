package com.example.nerd.tides;

import java.util.ArrayList;

/**
 * Created by nerd on 7/13/2017.
 */

public class TideItems extends ArrayList<TideItem> {
    //Extending ArrayList for extensibility

    //Default Serial ID
    private static final long serialVersionUID = 1L;
}
